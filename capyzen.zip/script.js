const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

let state = {
  coins:0,
  level:1,
  x:150,
  y:150
};

const coinsEl = document.getElementById("coins");
const levelEl = document.getElementById("level");
const msgEl = document.getElementById("msg");

function feed(){
  state.coins++;
  msgEl.innerText = "comeu 🍔";
}

function openAdmin(){
  const pass = prompt("senha:");
  if(pass !== "capivarassaomuitofofas404") return alert("negado");
  state.coins += 100;
}

document.addEventListener("keydown",(e)=>{
  if(e.key==="ArrowUp") state.y -= 5;
  if(e.key==="ArrowDown") state.y += 5;
  if(e.key==="ArrowLeft") state.x -= 5;
  if(e.key==="ArrowRight") state.x += 5;
});

function loop(){
  ctx.clearRect(0,0,300,300);

  ctx.fillStyle="#a47148";
  ctx.beginPath();
  ctx.arc(state.x,state.y,30,0,Math.PI*2);
  ctx.fill();

  coinsEl.innerText = state.coins;
  levelEl.innerText = state.level;

  requestAnimationFrame(loop);
}

loop();
