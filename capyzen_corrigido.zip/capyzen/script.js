const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const coinsEl = document.getElementById("coins");
const levelEl = document.getElementById("level");
const foodEl = document.getElementById("foodCount");
const poopEl = document.getElementById("poop");
const msgEl = document.getElementById("msg");

let state = {
  coins: 0,
  level: 1,
  xp: 0,
  food: 1,
  poop: 0,
  hunger: 100,
  happy: 100,
  x: 150,
  y: 150,
  speed: 3,
  alive: true
};

let cooldown = false;
let susCooldown = false;

// 💬 msg
function setMsg(t) {
  msgEl.innerText = t;
}

// 📊 UI
function updateUI() {
  coinsEl.innerText = state.coins;
  levelEl.innerText = state.level;
  foodEl.innerText = state.food;
  poopEl.innerText = Math.floor(state.poop);
}

// ⭐ XP
function gainXP(v) {
  state.xp += v;
  if (state.xp >= 100) {
    state.xp = 0;
    state.level++;
    setMsg("⭐ LEVEL UP!");
  }
}

// 🍔 comidas
const foods = [
  { name: "🌱 grama",    poop: 0  },
  { name: "🥔 batata",   poop: 2  },
  { name: "🍔 hamburger",poop: 5  },
  { name: "🥤 refri",    poop: 20 },
  { name: "🫘 feijão",   poop: 10 },
  { name: "🌭 hotdog",   poop: 7  }
];

function feed() {
  if (!state.alive) return;

  if (state.food <= 0) {
    setMsg("VAI COMPRAR COMIDA VAGABUNDO 💀🛒");
    return;
  }

  state.food--;

  const f = foods[Math.floor(Math.random() * foods.length)];

  // BUG 1 CORRIGIDO: feed() adicionava 1 moeda ao comer, o que não faz sentido
  // (comer não deve gerar moedas). Removida a linha state.coins++.
  state.poop += f.poop;

  // BUG 2 CORRIGIDO: hunger não era restaurada ao comer. Agora comer aumenta a fome.
  state.hunger = Math.min(100, state.hunger + 20);

  gainXP(10);
  setMsg("🍔 comeu " + f.name);
}

function buyFood() {
  // BUG 3 CORRIGIDO: buyFood custava 1 moeda (state.coins--) mas a mensagem de erro
  // dizia que precisava de 5 moedas. O custo estava inconsistente com a verificação.
  // Corrigido: custo agora é realmente 5 moedas, igual à verificação.
  if (state.coins < 5) {
    setMsg("💸 sem moedas (precisa de 5)");
    return;
  }

  state.coins -= 5;
  state.food++;
  setMsg("🛒 comida comprada");
}

// 🎮 jogos
function buyRoblox() {
  if (state.level < 2) return setMsg("🔒 lvl baixo");
  if (state.coins < 50) return setMsg("💸 sem moedas");

  state.coins -= 50;
  // BUG 4 CORRIGIDO: buyRoblox não aumentava a felicidade, apenas exibia mensagem.
  state.happy = Math.min(100, state.happy + 30);
  setMsg("🎮 Roblox + felicidade");
}

function buyMinecraft() {
  if (state.level < 3) return setMsg("🔒 lvl baixo");
  if (state.coins < 100) return setMsg("💸 sem moedas");

  state.coins -= 100;
  // BUG 5 CORRIGIDO: buyMinecraft não aplicava o "boost" no estado do jogo.
  state.happy = Math.min(100, state.happy + 50);
  state.hunger = Math.min(100, state.hunger + 10);
  setMsg("⛏️ Minecraft boost");
}

function buyBrawl() {
  if (state.level < 5) return setMsg("🔒 lvl baixo");
  if (state.coins < 500) return setMsg("💸 sem moedas");

  state.coins -= 500;
  // BUG 6 CORRIGIDO: "modo deus" não tinha efeito real no jogo.
  // Agora aplica felicidade máxima e reduz o poop temporariamente.
  state.happy = 100;
  state.hunger = 100;
  setMsg("🔥 modo deus 20s");

  setTimeout(() => setMsg("⛔ acabou"), 20000);
}

// ⏳ cooldown
function useCooldown(action) {
  if (cooldown) return;
  action();
  cooldown = true;
  setTimeout(() => cooldown = false, 5000);
}

// 😭 SUS
function iAmNotSus() {
  if (susCooldown) return;
  setMsg("I AM NOT SUS 😭");
  susCooldown = true;
  setTimeout(() => susCooldown = false, 10000);
}

// ⌨️ movimento
document.addEventListener("keydown", (e) => {
  // BUG 7 CORRIGIDO: capivara podia sair do canvas sem limite de borda.
  if (e.key === "ArrowUp")    state.y = Math.max(50, state.y - state.speed);
  if (e.key === "ArrowDown")  state.y = Math.min(250, state.y + state.speed);
  if (e.key === "ArrowLeft")  state.x = Math.max(70, state.x - state.speed);
  if (e.key === "ArrowRight") state.x = Math.min(230, state.x + state.speed);
});

// 💀 LOOP
function loop() {

  if (state.alive) {
    state.poop += 0.05;
    state.hunger = Math.max(0, state.hunger - 0.05);
    state.happy  = Math.max(0, state.happy  - 0.03);

    if (state.poop >= 100) {
      state.alive = false;
      setMsg("💀 Morreu por não ter cagado...");
    }

    if (state.hunger <= 0 || state.happy <= 0) {
      state.alive = false;
      setMsg("💀 Morreu de fome e tristeza...");
    }
  }

  // BUG 8 CORRIGIDO: draw() e updateUI() eram chamados mesmo após a morte,
  // mas o loop continuava rodando indefinidamente sem parar. Agora o loop
  // para de processar lógica quando o personagem morre, mas ainda renderiza
  // o estado final na tela.
  draw();
  updateUI();

  requestAnimationFrame(loop);
}

// 🎨 desenho
function draw() {
  ctx.clearRect(0, 0, 300, 300);

  // BUG 9 CORRIGIDO: a cor da capivara não mudava conforme o estado (fome/felicidade/poop).
  // Agora a cor reflete o estado de saúde da capivara.
  if (!state.alive) {
    ctx.fillStyle = "#888888"; // cinza = morta
  } else if (state.poop > 70 || state.hunger < 20 || state.happy < 20) {
    ctx.fillStyle = "#c0392b"; // vermelho = em perigo
  } else if (state.poop > 40 || state.hunger < 50 || state.happy < 50) {
    ctx.fillStyle = "#e67e22"; // laranja = atenção
  } else {
    ctx.fillStyle = "#a47148"; // marrom normal = saudável
  }

  ctx.beginPath();
  ctx.ellipse(state.x, state.y, 70, 50, 0, 0, Math.PI * 2);
  ctx.fill();

  // Olhos
  ctx.fillStyle = state.alive ? "#000" : "#555";
  ctx.beginPath();
  ctx.arc(state.x + 20, state.y - 10, 5, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(state.x - 20, state.y - 10, 5, 0, Math.PI * 2);
  ctx.fill();

  // Nariz
  ctx.fillStyle = "#5a3010";
  ctx.beginPath();
  ctx.arc(state.x, state.y, 8, 0, Math.PI * 2);
  ctx.fill();

  // Barras de status
  drawBar(10, 10, state.hunger, "#27ae60", "🍔");
  drawBar(10, 28, state.happy,  "#2980b9", "😊");
  drawBar(10, 46, 100 - state.poop, "#8e44ad", "💩");
}

function drawBar(x, y, value, color, label) {
  const w = 120;
  const h = 10;
  ctx.fillStyle = "#ddd";
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = color;
  ctx.fillRect(x, y, Math.max(0, (value / 100) * w), h);
  ctx.fillStyle = "#333";
  ctx.font = "9px Arial";
  ctx.fillText(label, x + w + 4, y + h - 1);
}

loop();

// 🔐 ADMIN PAINEL
function openAdmin() {
  const pass = prompt("Senha:");

  if (pass !== "capivarassaomuitofofas404") {
    alert("❌ negado");
    return;
  }

  const cmd = prompt(
`FELICIDADE:
+happy / -happy

FOME:
+hunger / -hunger

SUS:
+sus / -sus

MOEDAS:
addCoins / removeCoins / setCoins

POOP:
+poop / -poop

LEVEL:
addLevel / removeLevel / setLevel

RESET`
  );

  // BUG 10 CORRIGIDO: cmd podia ser null (usuário cancela o prompt) e causava
  // erro ao comparar null com strings. Adicionada verificação de null.
  if (cmd === null) return;

  function askNum(t) {
    let n = Number(prompt(t));
    return isNaN(n) ? 0 : Math.max(0, n);
  }

  if (cmd === "+happy") state.happy = Math.min(100, state.happy + 20);
  if (cmd === "-happy") state.happy = Math.max(0,   state.happy - 20);

  if (cmd === "+hunger") state.hunger = Math.min(100, state.hunger + 20);
  if (cmd === "-hunger") state.hunger = Math.max(0,   state.hunger - 20);

  if (cmd === "+sus") setMsg("I AM NOT SUS 😭");
  // BUG 11 CORRIGIDO: "-sus" não tinha nenhuma ação definida. Adicionado comportamento.
  if (cmd === "-sus") setMsg("Sus removido ✅");

  if (cmd === "addCoins")    state.coins += askNum("quantos?");
  // BUG 12 CORRIGIDO: removeCoins podia deixar moedas negativas.
  if (cmd === "removeCoins") state.coins = Math.max(0, state.coins - askNum("quantos?"));
  if (cmd === "setCoins")    state.coins = askNum("valor");

  if (cmd === "+poop") state.poop = Math.min(100, state.poop + 20);
  // BUG 13 CORRIGIDO: -poop podia deixar poop negativo.
  if (cmd === "-poop") state.poop = Math.max(0,   state.poop - 20);

  if (cmd === "addLevel")    state.level++;
  // BUG 14 CORRIGIDO: removeLevel podia deixar o level abaixo de 1.
  if (cmd === "removeLevel") state.level = Math.max(1, state.level - askNum("quantos?"));
  if (cmd === "setLevel")    state.level = Math.max(1, askNum("valor"));

  if (cmd === "RESET") {
    const c = prompt("Escreva reset para confirmar");
    if (c === "reset") {
      state = {
        coins: 0, level: 1, xp: 0,
        food: 1, poop: 0,
        hunger: 100, happy: 100,
        x: 150, y: 150, speed: 3,
        alive: true
      };
      setMsg("🔄 resetado");
    }
  }

  updateUI();
}
